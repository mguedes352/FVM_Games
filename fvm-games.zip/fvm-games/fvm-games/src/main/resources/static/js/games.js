
var token = localStorage.getItem('token');
if (!token) {
	window.location.replace("/html/login.html");
}

// document.getElementById("img-ext").innerHTML = "<img src='#txtUrlImg' width='250'>"
const corpoTabela = document.querySelector('#corpoTabelaGames');
const paragrafoMensagem = document.querySelector('#paragrafoMensagem');
const txtNome = document.querySelector('#txtNome');
const txtDesc = document.querySelector('#txtDesc');
const txtUrlGame = document.querySelector('#txtUrlGame');
const txtUrlDemo = document.querySelector('#txtUrlDemo');
const txtUrlImg = document.querySelector('#txtUrlImg');
const txtId = document.querySelector('#txtId');
const selectCategoria = document.querySelector('#selectCategoria');
const btnNovo = document.querySelector('#btnNovo');
const btnSalvar = document.querySelector('#btnSalvar');
const btnApagar = document.querySelector('#btnApagar');
const btnCancelar = document.querySelector('#btnCancelar');
var criandoNovoGame = false;
	        
inicializar();

function inicializar() {
    criandoNovoGame = false;
    paragrafoMensagem.innerHTML = 'Pressione o botão Novo ou selecione um game da lista:'
    txtId.value = '';
    txtNome.value = '';
    txtDesc.value = '';
    txtUrlGame.value = '';
    txtUrlDemo.value = '';
    txtUrlImg.value = '';

    txtId.disabled = true;
    txtNome.disabled = true;
    txtDesc.disabled = true;
    txtUrlGame.disabled = true;
    txtUrlDemo.disabled = true;
    txtUrlImg.disabled = true;
    selectCategoria.disabled = true;
    carregarCategorias();
     selectCategoria.selectedIndex = -1;
   
    btnNovo.disabled = false;
    btnSalvar.disabled = true;
    btnApagar.disabled = true;
    btnCancelar.disabled = true;

    listarTodosGames();            
}

async function listarTodosGames() {
    fetch('/api/games' ,{
    method: 'GET',
    headers: {'Authorization': 'Bearer ' + token }
    })
      .then(resposta => { if (!resposta.ok) throw Error(resposta.status); return resposta;})
      .then(resposta => resposta.json())
      .then(jsonResponse => preencherTabela(jsonResponse))
      .catch(function(error) { paragrafoMensagem.innerHTML = "Erro ao listar games (código " + error.message + ")";});
}

function preencherTabela(games) {
    var linhasTabela = '';
    var n = games.length;
    for (var i = 0; i < n; i++) {
        var g = games[i];
        linhasTabela += 
            `<tr><td><a href="javascript:void(0)" onclick="selecionarGame('${g.id}','${g.nomeGame}','${g.categoria.id}','${g.descGame}','${g.urlGame}','${g.urlDemo}','${g.urlImg}')">`
            + g.id    + '</a></td>' + 
            '<td>' + g.nomeGame   + '</td>' +
            '<td>' + g.categoria.nomeCat   + '</td>' +
            '<td>' + g.descGame   + '</td>' +
            '<td>' + g.urlGame  + '</td>' +
            '<td>' + g.urlDemo  + '</td>' +
            '<td>' + g.urlImg + '</td></tr>\n';
    }
    corpoTabela.innerHTML = linhasTabela;
}

async function carregarCategorias() {
    fetch('/api/categorias' ,{
    method: 'GET',
    headers: {'Authorization': 'Bearer ' + token }
    })
      .then(resposta => { if (!resposta.ok) throw Error(resposta.status); return resposta;}) 
      .then(resposta => resposta.json())
      .then(jsonResponse => preencherSelectCategorias(jsonResponse))
      .catch(function(error) { paragrafoMensagem.innerHTML = "Erro ao carregar categorias (código " + error.message + ")";});
}

function preencherSelectCategorias(categorias) {
    var opcoes = '';
    var n = categorias.length;
    for (var i = 0; i < n; i++) {
        var c = categorias[i];
        opcoes += `<option value="${c.id}">${c.nomeCat}</option>`
    }
    selectCategoria.innerHTML = opcoes;
}

function selecionarGame(idGame, nomeGame, categoriaId, descGame, urlGame, urlDemo, urlImg) {
    criandoNovoGame = false;
    // carregarCategorias();
    
    paragrafoMensagem.innerHTML = 'Altere e salve os dados do game, ou então apague o registro do game.'
    txtId.value = idGame;
    txtNome.value = nomeGame;
    txtDesc.value = descGame;
    txtUrlGame.value = urlGame;
    txtUrlDemo.value = urlDemo;
    txtUrlImg.value = urlImg;
    selectCategoria.value = categoriaId;
    console.log('categoriaId: ', categoriaId);
    
    txtId.disabled = true;
    txtNome.disabled = false;
    txtDesc.disabled = false;
    txtUrlGame.disabled = false;
    txtUrlDemo.disabled = false;
    txtUrlImg.disabled = false;
    selectCategoria.disabled = false;
    
    btnNovo.disabled = true;
    btnSalvar.disabled = false;
    btnApagar.disabled = false;
    btnCancelar.disabled = false;  
}

function novoGame() {
    paragrafoMensagem.innerHTML = 'Preencha os dados do novo game...';
    criandoNovoGame = true;
    carregarCategorias();
    
    txtId.value = '';
    txtNome.value = '';
    txtDesc.value = '';
    txtUrlGame.value = '';
    txtUrlDemo.value = '';
    txtUrlImg.value = '';
    selectCategoria.selectedIndex = -1;
    
    txtId.disabled = true;
    txtNome.disabled = false;
    txtDesc.disabled = false;
    txtUrlGame.disabled = false;
    txtUrlDemo.disabled = false;
    txtUrlImg.disabled = false;
    selectCategoria.disabled = false;
    
    btnNovo.disabled = true;
    btnSalvar.disabled = false;
    btnApagar.disabled = true;
    btnCancelar.disabled = false;
}

function salvarGame() {
    if (criandoNovoGame) {
        criarGame();
    }
    else {
        alterarGame();
    }
}

async function criarGame() {
    
    fetch('/api/games', {
        method: 'POST',
        body: JSON.stringify({
        'nomeGame': txtNome.value,
        'categoria': {
            'id': selectCategoria.value
        },
        'descGame': txtDesc.value,
        'urlGame': txtUrlGame.value,
        'urlDemo': txtUrlDemo.value,
        'urlImg': txtUrlImg.value
    }),
        headers: {
            'Content-type': 'application/json',
            'Authorization': 'Bearer ' + token
        }
    })
        .then(resposta => { if (!resposta.ok) throw Error(resposta.status); return resposta; } )
        .then(resposta => resposta.json())
        .then(jsonResponse => inicializar())
        .catch(function(error) { paragrafoMensagem.innerHTML = 'Erro ao criar novo game (código ' + error.message + ')'; } );
}

async function alterarGame() {
    const ID = txtId.value;
    const URL = `/api/games/${ID}`; 
    const dadosGame = {
        'id': ID,
        'nomeGame': txtNome.value,
        'categoria': {
            'id': selectCategoria.value
        },
        'descGame': txtDesc.value,
        'urlGame': txtUrlGame.value,
        'urlDemo': txtUrlDemo.value,
        'urlImg': txtUrlImg.value
    };
    const putRequest = {
        method: 'PUT',
        body: JSON.stringify(dadosGame),
        headers: { 'Content-type': 'application/json', 'Authorization': 'Bearer ' + token }
    };
    fetch(URL, putRequest)
        .then(resposta => { if (!resposta.ok) throw Error(resposta.status); return resposta; } )
        .then(resposta => resposta.json())
        .then(jsonResponse => inicializar())
        .catch(function(error) { paragrafoMensagem.innerHTML = 'Erro ao alterar game (código ' + error.message + ')'; } );	        	
}

function cancelarEdicao() {
    inicializar();
}

async function apagarGame() {
    const ID = txtId.value;
    const URL = `/api/games/${ID}`;
    const deleteRequest = {
        method: 'DELETE',
        headers: {'Authorization': 'Bearer ' + token }
    };
    fetch(URL, deleteRequest)
        .then(resposta => { if (!resposta.ok) throw Error(resposta.status); return resposta; } )
        .then(resposta => inicializar())
        .catch(function(error) { paragrafoMensagem.innerHTML = 'Erro ao apagar game (código ' + error.message + ')'; } );	        		
}
