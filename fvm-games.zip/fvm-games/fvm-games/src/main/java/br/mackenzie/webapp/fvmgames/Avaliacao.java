package br.mackenzie.webapp.fvmgames;

import javax.persistence.*;

@Entity
@Table(name = "avaliacoes")
public class Avaliacao {

    @Id @GeneratedValue
    private long id;
    private String nota;
    private String comentario;
    
    @ManyToOne(fetch=FetchType.EAGER, optional = false)
    private Game game;

    public Avaliacao() {
        super();
    }

    public long getId() {return id;}
    public void setId(long id) {this.id = id;}

    public String getNota() {return nota;}
    public void setNota(String nota) {this.nota = nota;}

    public String getComentario() {return comentario;}
    public void setComentario(String comentario) {this.comentario = comentario;}

    public Game getGame(){return game;}
    public void setGame(Game game){this.game = game;}
    
}
