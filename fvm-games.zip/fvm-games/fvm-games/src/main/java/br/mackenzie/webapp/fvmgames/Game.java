package br.mackenzie.webapp.fvmgames;

import javax.persistence.*;

@Entity
@Table(name = "games")
public class Game {

    @Id @GeneratedValue
    private long id;
    private String nome_game;
    private String desc_game;
    private String url_game;
    private String url_demo;
    private String url_img;

    @ManyToOne(fetch=FetchType.EAGER, optional = false)
    private Categoria categoria;

    public Game() {
        super();
    }
    
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNomeGame() {return nome_game;}
    public void setNomeGame(String nome_game) {this.nome_game = nome_game;}

    public String getDescGame() {return desc_game;}
    public void setDescGame(String desc_game) {this.desc_game = desc_game;}

    public String getUrlGame() {return url_game;}
    public void setUrlGame(String url_game) {this.url_game = url_game;}

    public String getUrlDemo() {return url_demo;}
    public void setUrlDemo(String url_demo) {this.url_demo = url_demo;}

    public String getUrlImg() {return url_img;}
    public void setUrlImg(String url_img) {this.url_img = url_img;}

    public Categoria getCategoria(){return categoria;}
    public void setCategoria(Categoria categoria){this.categoria = categoria;}

}
