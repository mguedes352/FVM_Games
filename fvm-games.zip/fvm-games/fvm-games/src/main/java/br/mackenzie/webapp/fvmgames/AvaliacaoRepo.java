package br.mackenzie.webapp.fvmgames;

import org.springframework.data.repository.CrudRepository;

public interface AvaliacaoRepo extends CrudRepository<Avaliacao, Long> {
    Iterable<Avaliacao> findByGameId(Long gameId);
}
