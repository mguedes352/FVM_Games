package br.mackenzie.webapp.fvmgames;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
class CategoriaController {

    @Autowired
    private CategoriaRepo categoriaRepo;

    //Listar todas as categorias da tabela
    @GetMapping("/api/categorias")
    Iterable<Categoria> getCategorias() {
        return categoriaRepo.findAll();
    }

    //Listar categoria por Id
    @GetMapping("/api/categorias/{id}")
    Optional<Categoria> getCategoria(@PathVariable long id) {
        return categoriaRepo.findById(id);
    }

    //Criar uma categoria
    @PostMapping("/api/categorias")
    Categoria createCategoria(@RequestBody Categoria c) {
        Categoria createdCategoria = categoriaRepo.save(c);
        return createdCategoria;
    }

    //Editar uma categoria
    @PutMapping("/api/categorias/{categoriaId}")
    Optional<Categoria> updateCategoria(@RequestBody Categoria categoriaReq, @PathVariable long categoriaId) {
        Optional<Categoria> opt = categoriaRepo.findById(categoriaId);
        if (opt.isPresent()) {
            if (categoriaReq.getId() == categoriaId) {
                categoriaRepo.save(categoriaReq);
                return opt;
            }
        }
        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro ao alterar dados da categoria de id " + categoriaId);
    }

    //Deletar uma categoria
    @DeleteMapping(value = "/api/categorias/{id}")
    void deleteCategoria(@PathVariable long id) {
        categoriaRepo.deleteById(id);
    }

}