package br.mackenzie.webapp.fvmgames;


import javax.persistence.*;

@Entity
@Table(name = "avaliacao_game")
public class AvaliacaoGame {

    @Id @GeneratedValue
    private long id;
    private String nomeGame;
    private int nota;
    private String desc;

    @ManyToOne(fetch=FetchType.EAGER, optional=false)
	private Game game;

    public AvaliacaoGame(){
        super();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNomeGame() {
        return nomeGame;
    }

    public void setNomeGame(String nomeGame) {
        this.nomeGame = nomeGame;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    
}
