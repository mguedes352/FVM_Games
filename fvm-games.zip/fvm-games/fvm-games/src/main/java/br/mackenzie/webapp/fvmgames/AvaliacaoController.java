package br.mackenzie.webapp.fvmgames;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
class AvaliacaoController {

    @Autowired
    private AvaliacaoRepo avaliacaoRepo;

    //Listar todas as avaliacoes da tabela
    @GetMapping("/api/avaliacoes")
    Iterable<Avaliacao> getAvaliacoes(@RequestParam Optional<Long> gameId) {
        if (gameId.isEmpty()) { 
            return avaliacaoRepo.findAll();
        }
        return avaliacaoRepo.findByGameId(gameId.get());
    }

    //Listar avaliacoes por Id
    @GetMapping("/api/avaliacoes/{id}")
    Optional<Avaliacao> getAvaliacao(@PathVariable long id) {
        return avaliacaoRepo.findById(id);
    }

    //Criar uma avaliacao
    @PostMapping("/api/avaliacoes")
    Avaliacao createAvaliacao(@RequestBody Avaliacao a) {
        Avaliacao createdAvaliacao = avaliacaoRepo.save(a);
        return createdAvaliacao;
    }

    //Editar uma avaliação
    @PutMapping("/api/avaliacoes/{avaliacaoId}")
    Optional<Avaliacao> updateAvaliacao(@RequestBody Avaliacao avaliacaoReq, @PathVariable long avaliacaoId) {
        Optional<Avaliacao> opt = avaliacaoRepo.findById(avaliacaoId);
        if (opt.isPresent()) {
            if (avaliacaoReq.getId() == avaliacaoId) {
                avaliacaoRepo.save(avaliacaoReq);
                return opt;
            }
        }
        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro ao alterar dados da avaliacao de id " + avaliacaoId);
    }

    //Deletar uma avaliacao
    @DeleteMapping(value = "/api/avaliacoes/{id}")
    void deleteAvaliacao(@PathVariable long id) {
        avaliacaoRepo.deleteById(id);
    }

}