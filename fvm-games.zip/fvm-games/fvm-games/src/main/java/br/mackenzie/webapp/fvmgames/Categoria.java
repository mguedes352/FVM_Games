package br.mackenzie.webapp.fvmgames;

import javax.persistence.*;

@Entity
@Table(name = "categorias")
public class Categoria {

    @Id @GeneratedValue
    private long id;
    private String nome_cat;
    private String desc_cat;
    

    public Categoria() {
        super();
    }

    public long getId() {return id;}
    public void setId(long id) {this.id = id;}

    public String getNomeCat() {return nome_cat;}
    public void setNomeCat(String nome_cat) {this.nome_cat = nome_cat;}

    public String getDescCat() {return desc_cat;}
    public void setDescCat(String desc_cat) {this.desc_cat = desc_cat;}
}
