package br.mackenzie.webapp.fvmgames;

import org.springframework.data.repository.CrudRepository;

public interface AvaliacaoGameRepo extends CrudRepository<AvaliacaoGame, Long> {
    Iterable<AvaliacaoGame> findByGameId(Long gameId);
}
