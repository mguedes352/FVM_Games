package br.mackenzie.webapp.fvmgames;

import org.springframework.data.repository.CrudRepository;

public interface CategoriaRepo extends CrudRepository<Categoria, Long> {
}
