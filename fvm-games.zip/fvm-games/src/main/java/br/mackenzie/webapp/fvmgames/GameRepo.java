package br.mackenzie.webapp.fvmgames;

import org.springframework.data.repository.CrudRepository;

public interface GameRepo extends CrudRepository<Game, Long> {
    Iterable<Game> findByCategoriaId(Long categoriaId);
}
