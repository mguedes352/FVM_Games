package br.mackenzie.webapp.fvmgames;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
class GameController {

    @Autowired
    private GameRepo gameRepo;

    public GameController(){

    }

    //Listar todos os games da tabela
    @GetMapping("/api/games")
    Iterable<Game> getGames(@RequestParam Optional<Long> categoriaId) {
        if (categoriaId.isEmpty()) { 
            return gameRepo.findAll();
        }
        return gameRepo.findByCategoriaId(categoriaId.get());
    }

    //Listar games por Id
    @GetMapping("/api/games/{id}")
    Optional<Game> getGame(@PathVariable long id) {
        return gameRepo.findById(id);
    }


    //Criar um game
    @PostMapping("/api/games")
    Game createGame(@RequestBody Game g) {
        Game createdGame = gameRepo.save(g);
        return createdGame;
    }

    //Editar um game
    @PutMapping("/api/games/{gameId}")
    Optional<Game> updateGame(@RequestBody Game gameRequest, @PathVariable long gameId) {
        Optional<Game> opt = gameRepo.findById(gameId);

        if (opt.isPresent()) {
            if (gameRequest.getIdGame() == gameId) {
                gameRepo.save(gameRequest);
                return opt;
            }
        }
        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Erro ao alterar dados do game de id " + gameId);
    }

    //Deletar um game
    @DeleteMapping(value = "/api/games/{id}")
    void deleteGame(@PathVariable long id) {gameRepo.deleteById(id);}


}
