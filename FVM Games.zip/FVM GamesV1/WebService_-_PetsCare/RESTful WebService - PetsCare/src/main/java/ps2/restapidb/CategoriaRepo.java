package ps2.restapidb;

import org.springframework.data.repository.CrudRepository;

public interface CategoriaRepo extends CrudRepository<Categoria, Long> {
}
