package ps2.restapidb;

import javax.persistence.*;

@Entity
@Table(name = "games")
public class Game {

    @Id @GeneratedValue
    private long id_game;
    private String nome_game;
    private String categoria_game;
    private String desc_game;
    private String url_game;
    private String url_demo;
    private String url_img;

    public Game() {}
    public Game(long id, String ng, String cg, String dg, String ug, String ud, String ui){

        this.id_game = id;
        this.nome_game = ng;
        this.categoria_game = cg;
        this.desc_game = dg;
        this.url_game = ug;
        this.url_demo = ud;
        this.url_img = ui;
    }

    public long getIdGame() {return id_game;}
    public void setIdGame(long id_game) {this.id_game = id_game;}

    public String getNomeGame() {return nome_game;}
    public void setNomeGame(String nome_game) {this.nome_game = nome_game;}

    public String getCatGame() {return categoria_game;}
    public void setCatGame(String categoria_game) {this.categoria_game = categoria_game;}

    public String getDescGame() {return desc_game;}
    public void setDescGame(String desc_game) {this.desc_game = desc_game;}

    public String getURLGame() {return url_game;}
    public void setURLGame(String url_game) {this.url_game = url_game;}

    public String getURLDemo() {return url_demo;}
    public void setURLDemo(String url_demo) {this.url_demo = url_demo;}

    public String getURLImg() {return url_img;}
    public void setURLImg(String url_img) {this.url_img = url_img;}

}
