package ps2.restapidb;

import javax.persistence.*;

@Entity
@Table(name = "categorias")
public class Categoria {

    @Id @GeneratedValue
    private long id;
    private String nome_cat;
    private String desc_cat;
    

    public Categoria() {}
    public Categoria(long id, String nc, String dc){

        this.id = id;
        this.nome_cat = nc;
        this.desc_cat = dc;
        
    }

    public long getId() {return id;}
    public void setId(long id) {this.id = id;}

    public String getNomeCat() {return nome_cat;}
    public void setNomeCat(String nome_cat) {this.nome_cat = nome_cat;}

    public String getDescCat() {return desc_cat;}
    public void setDescCat(String desc_cat) {this.desc_cat = desc_cat;}
}
