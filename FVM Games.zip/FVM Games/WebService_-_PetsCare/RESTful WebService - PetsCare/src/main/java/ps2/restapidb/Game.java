package ps2.restapidb;

import javax.persistence.*;

@Entity
@Table(name = "games")
public class Game {

    @Id @GeneratedValue
    private long id;
    private String nome;
    private String cat;
    private String descricao;
    private String urlGame;
    private String urlDemo;
    private String urlImg;

    public Game() {}
    public Game(long id, String nome, String cat, String descricao, 
    String urlGame, String urlDemo, String urlImg){

        this.id = id;
        this.nome = nome;
        this.cat = cat;
        this.descricao = descricao;
        this.urlGame = urlGame;
        this.urlDemo = urlDemo;
        this.urlImg = urlImg;
    }

    public long getIdGame() {return id;}
    public void setIdGame(long id) {this.id = id;}

    public String getNomeGame() {return nome;}
    public void setNomeGame(String nome) {this.nome = nome;}

    public String getCatGame() {return cat;}
    public void setCatGame(String cat) {this.cat = cat;}

    public String getDescGame() {return descricao;}
    public void setDescGame(String descricao) {this.descricao = descricao;}

    public String getURLGame() {return urlGame;}
    public void setURLGame(String urlGame) {this.urlGame = urlGame;}

    public String getURLDemo() {return urlDemo;}
    public void setURLDemo(String urlDemo) {this.urlDemo = urlDemo;}

    public String getURLImg() {return urlImg;}
    public void setURLImg(String urlImg) {this.urlImg = urlImg;}

}
